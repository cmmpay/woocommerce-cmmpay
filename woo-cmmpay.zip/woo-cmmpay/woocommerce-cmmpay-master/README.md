
1. From CMMPay you will need

ACCOUNT -> API Credentials & Keys 

API Login ID

Transaction Key

Signature Key

2. Get the plugin from github:

https://github.com/cmmpay/cmmpay-plugins/releases/latest

Look for the woo-cmmpay.zip file and download it

3. Install the plugin in Wordpress:

Go to WordPress Plugin page

/wp-admin/plugins.php

Select [Add New]

Select [Upload Plugin] button (right next to Add Plugins title at top of page)

Select [Browse] and select the .zip file and press [Open]

Select [Install Now]

4. Configure "CMMPay Payment Gateway For WooCommerce":

From the Plugin page find the plugin and Select [Settings]

Here you will need to enter the API Login ID, Transaction Key and Signature Key obtained from CMMPay
